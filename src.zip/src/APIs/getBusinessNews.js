import axios from "axios"
const API = 'https://newsapi.org/v2/top-headlines?country=us&apiKey=2da9af78cad94a1688a3dcc4ad023aab'
let data=null
export const getBusinessNews = async() => {

    await axios.get(`${API}`).then(res=>{

        console.log(res.data)
        data = res.data

    })
    .catch(err=>{

        console.log(err)

    })
    return data;
}  