import './App.css';
import { BrowserRouter, Routes, Route} from "react-router-dom";
import Business from './Components/Business/index.js';
import Navigation from './Components/Navigation/index.js'

function App() {
  return (
    <>
      <Navigation />
      <Routes>
        <Route path = "business" element={<Business/>} />
      </Routes>
    </>
  );
}

export default App;
